import React, { useState } from "react";
import { View, Text, TextInput, Button, Picker, Alert, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

const TaskForm: React.FC = () => {
  const navigation = useNavigation();
  const [taskTitle, setTaskTitle] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [newCategory, setNewCategory] = useState<string>("");
  const [categories, setCategories] = useState<string[]>(["Eğitim", "Sağlık", "İş", "Diğer"]);

  const handleSaveTask = () => {
    if (taskTitle === "") {
      Alert.alert("Hata", "Görev adı boş olamaz!");
      return;
    }

    let category = selectedCategory;
    if (selectedCategory === "Diğer" && newCategory !== "") {
      category = newCategory;
      // Yeni kategori ekleniyor
      setCategories((prevCategories) => [...prevCategories, newCategory]);
    } else if (selectedCategory === "Diğer" && newCategory === "") {
      Alert.alert("Hata", "Lütfen geçerli bir kategori adı girin.");
      return;
    }

    // Görevi kaydedin (Burada bir veri yapısına ekleyebiliriz)
    Alert.alert("Başarılı", `Görev başarıyla eklendi! Kategori: ${category}`);
    navigation.goBack(); // Başarıyla kaydedildikten sonra geri dön
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Yeni Görev Oluştur</Text>

      {/* Görev Başlığı */}
      <TextInput
        style={styles.input}
        placeholder="Görev adı"
        value={taskTitle}
        onChangeText={setTaskTitle}
      />

      {/* Kategori Seçimi */}
      <Text style={styles.label}>Kategori Seçin:</Text>
      <Picker
        selectedValue={selectedCategory}
        style={styles.picker}
        onValueChange={(itemValue) => setSelectedCategory(itemValue)}
      >
        {categories.map((category) => (
          <Picker.Item key={category} label={category} value={category} />
        ))}
      </Picker>

      {/* Yeni kategori girme */}
      {selectedCategory === "Diğer" && (
        <View style={styles.addCategoryContainer}>
          <TextInput
            style={styles.input}
            placeholder="Yeni kategori adı"
            value={newCategory}
            onChangeText={setNewCategory}
          />
        </View>
      )}

      <Button title="Görevi Kaydet" onPress={handleSaveTask} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  input: { height: 40, borderColor: "gray", borderWidth: 1, marginBottom: 20, paddingLeft: 10 },
  picker: { height: 50, marginBottom: 20 },
  label: { fontSize: 16 },
  addCategoryContainer: { marginTop: 10 },
});

export default TaskForm;
