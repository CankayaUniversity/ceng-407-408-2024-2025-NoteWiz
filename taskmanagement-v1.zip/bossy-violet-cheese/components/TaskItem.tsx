// src/components/TaskItem.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export const TaskItem = ({ task }: any) => {
  return (
    <View style={styles.taskContainer}>
      <Text style={styles.taskTitle}>{task.title}</Text>
      <Text>{task.description}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  taskContainer: {
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#f4f4f4',
    borderRadius: 5,
  },
  taskTitle: {
    fontWeight: 'bold',
    fontSize: 16,
  },
});
