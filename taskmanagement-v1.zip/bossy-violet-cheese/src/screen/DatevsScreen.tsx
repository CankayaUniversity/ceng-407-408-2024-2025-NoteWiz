import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet, Switch, Picker } from "react-native";
import { useNavigation } from "@react-navigation/native";

interface Task {
  id: string;
  title: string;
  date: string;
  category?: string;
  completed: boolean;
  priority?: string; // High, Medium, Low
}

const ExtraScreen: React.FC = () => {
  const navigation = useNavigation();
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDate, setTaskDate] = useState("");
  const [taskCategory, setTaskCategory] = useState("");
  const [taskPriority, setTaskPriority] = useState("Medium");
  const [isCompleted, setIsCompleted] = useState(false);

  const handleSaveTask = () => {
    const newTask: Task = {
      id: Date.now().toString(),
      title: taskTitle,
      date: taskDate,
      category: taskCategory,
      completed: isCompleted,
      priority: taskPriority,
    };

    // Assuming you have a function to handle adding the task
    navigation.navigate("TaskList", { newTask });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Görev Başlığı:</Text>
      <TextInput style={styles.input} value={taskTitle} onChangeText={setTaskTitle} />

      <Text style={styles.label}>Görev Tarihi:</Text>
      <TextInput style={styles.input} value={taskDate} onChangeText={setTaskDate} />

      <Text style={styles.label}>Kategori Seç:</Text>
      <Picker selectedValue={taskCategory} onValueChange={setTaskCategory} style={styles.input}>
        <Picker.Item label="İş" value="Work" />
        <Picker.Item label="Kişisel" value="Personal" />
        <Picker.Item label="Eğitim" value="Education" />
      </Picker>

      <Text style={styles.label}>Öncelik Seviyesi:</Text>
      <Picker selectedValue={taskPriority} onValueChange={setTaskPriority} style={styles.input}>
        <Picker.Item label="Yüksek" value="High" />
        <Picker.Item label="Orta" value="Medium" />
        <Picker.Item label="Düşük" value="Low" />
      </Picker>

      <Text style={styles.label}>Tamamlandı:</Text>
      <Switch value={isCompleted} onValueChange={setIsCompleted} />

      <Button title="Kaydet" onPress={handleSaveTask} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center", backgroundColor: "#fff" },
  label: { fontSize: 18, marginBottom: 8 },
  input: { borderWidth: 1, padding: 10, borderRadius: 8, marginBottom: 10 },
});

export default ExtraScreen;
