import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet } from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";

interface Task {
  id: string;
  title: string;
  completed: boolean;
}

const AddTaskScreen: React.FC = () => {
  const navigation = useNavigation();
  const route = useRoute<{ params?: { onTaskAdded?: (task: Task) => void } }>();

  const [taskTitle, setTaskTitle] = useState("");

  const handleAddTask = () => {
    if (taskTitle.trim().length > 0) {
      const newTask: Task = { id: Date.now().toString(), title: taskTitle, completed: false };
      route.params?.onTaskAdded?.(newTask); // ✅ Görevi liste ekranına ekler
      navigation.goBack(); // ✅ Geri dön
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Görev Başlığı:</Text>
      <TextInput style={styles.input} placeholder="Yeni görev girin..." value={taskTitle} onChangeText={setTaskTitle} />
      <Button title="Ekle" onPress={handleAddTask} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center", backgroundColor: "#fff" },
  label: { fontSize: 18, marginBottom: 8 },
  input: { borderWidth: 1, padding: 10, borderRadius: 8, marginBottom: 10 },
});

export default AddTaskScreen;
