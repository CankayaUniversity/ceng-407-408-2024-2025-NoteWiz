import React, { useState, useEffect, useCallback } from "react";
import { View, Text, FlatList, TouchableOpacity, Button, TextInput, StyleSheet, Alert, Picker } from "react-native";
import { useNavigation } from "@react-navigation/native";

interface Task {
  id: string;
  title: string;
  date: string;
  completed: boolean;
  category?: string;
}

const TaskListScreen: React.FC = () => {
  const navigation = useNavigation();
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", title: "Ders çalış", date: "2024-04-01", completed: false, category: "Eğitim" },
    { id: "2", title: "Spor yap", date: "2024-04-02", completed: false, category: "Sağlık" },
    { id: "3", title: "Kitap oku", date: "2024-04-03", completed: false, category: "Eğitim" },
  ]);
  const [filteredTasks, setFilteredTasks] = useState<Task[]>(tasks);
  const [selectedCategory, setSelectedCategory] = useState<string>("Tümü");
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [showAddTaskModal, setShowAddTaskModal] = useState<boolean>(false);
  const [newTaskTitle, setNewTaskTitle] = useState<string>("");
  const [newTaskDate, setNewTaskDate] = useState<string>("");
  const [newTaskCategory, setNewTaskCategory] = useState<string>("Eğitim");

  const handleDeleteTask = (taskId: string) => {
    Alert.alert("Görevi Sil", "Bu görevi silmek istediğinize emin misiniz?", [
      { text: "İptal", style: "cancel" },
      { text: "Sil", onPress: () => setTasks((prevTasks) => prevTasks.filter((task) => task.id !== taskId)) },
    ]);
  };

  const handleCompleteTask = (taskId: string) => {
    setTasks((prevTasks) =>
      prevTasks.map((task) =>
        task.id === taskId ? { ...task, completed: !task.completed } : task
      )
    );
  };

  // Görev ekleme fonksiyonu
  const handleAddTask = () => {
    if (!newTaskTitle || !newTaskDate) {
      Alert.alert("Hata", "Başlık ve tarih gereklidir!");
      return;
    }

    const newTask = {
      id: (tasks.length + 1).toString(),
      title: newTaskTitle,
      date: newTaskDate,
      completed: false,
      category: newTaskCategory,
    };

    setTasks((prevTasks) => [...prevTasks, newTask]);
    setShowAddTaskModal(false); // Görev ekleme formunu kapat
  };

  // Filter tasks
  const filterTasks = useCallback(() => {
    let filtered = tasks;

    if (selectedCategory !== "Tümü") {
      filtered = filtered.filter((task) => task.category === selectedCategory);
    }

    if (selectedDate) {
      filtered = filtered.filter((task) => task.date === selectedDate);
    }

    setFilteredTasks(filtered);
  }, [tasks, selectedCategory, selectedDate]);

  useEffect(() => {
    filterTasks();
  }, [filterTasks]);

  const renderItem = ({ item }: { item: Task }) => (
    <View style={styles.taskItem}>
      <TouchableOpacity
        style={[styles.taskContainer, item.completed && styles.completedTask]}
      >
        <Text style={[styles.taskText, item.completed && styles.completedText]}>
          {item.title} - {item.date} - {item.category}
        </Text>
      </TouchableOpacity>
      <Button title="✏️" onPress={() => navigation.navigate("EditTask", { task: item })} />
      <Button title="🗑️" color="red" onPress={() => handleDeleteTask(item.id)} />
      <Button
        title={item.completed ? "Tamamlanmış" : "Tamamla"}
        onPress={() => handleCompleteTask(item.id)}
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Görev Listesi</Text>

      {/* Filtreleme UI */}
      <Text style={styles.filterTitle}>Filtreleme:</Text>
      <View style={styles.filterContainer}>
        <Text>Kategori:</Text>
        <Picker selectedValue={selectedCategory} onValueChange={setSelectedCategory} style={styles.picker}>
          <Picker.Item label="Tümü" value="Tümü" />
          <Picker.Item label="Eğitim" value="Eğitim" />
          <Picker.Item label="Sağlık" value="Sağlık" />
          <Picker.Item label="İş" value="İş" />
          <Picker.Item label="Kişisel" value="Kişisel" />
        </Picker>

        <Text>Tarih:</Text>
        <Picker selectedValue={selectedDate} onValueChange={setSelectedDate} style={styles.picker}>
          <Picker.Item label="Tümü" value="" />
          <Picker.Item label="2024-04-01" value="2024-04-01" />
          <Picker.Item label="2024-04-02" value="2024-04-02" />
          <Picker.Item label="2024-04-03" value="2024-04-03" />
        </Picker>
      </View>

      <FlatList data={filteredTasks} renderItem={renderItem} keyExtractor={(item) => item.id} />

      {/* Görev Ekle butonu */}
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => setShowAddTaskModal(true)}
      >
        <Text style={styles.addButtonText}>Görev Ekle</Text>
      </TouchableOpacity>

      {/* Görev Ekleme Modal/Form */}
      {showAddTaskModal && (
        <View style={styles.modal}>
          <TextInput
            style={styles.input}
            placeholder="Görev Başlığı"
            value={newTaskTitle}
            onChangeText={setNewTaskTitle}
          />
          <TextInput
            style={styles.input}
            placeholder="Tarih (YYYY-MM-DD)"
            value={newTaskDate}
            onChangeText={setNewTaskDate}
          />
          <Picker
            selectedValue={newTaskCategory}
            onValueChange={setNewTaskCategory}
            style={styles.picker}
          >
            <Picker.Item label="Eğitim" value="Eğitim" />
            <Picker.Item label="Sağlık" value="Sağlık" />
            <Picker.Item label="İş" value="İş" />
            <Picker.Item label="Kişisel" value="Kişisel" />
          </Picker>

          <Button title="Ekle" onPress={handleAddTask} />
          <Button title="Kapat" onPress={() => setShowAddTaskModal(false)} />
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#fff" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  taskItem: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  taskContainer: { flex: 1, padding: 15, backgroundColor: "#f9c2ff", borderRadius: 10 },
  taskText: { fontSize: 18 },
  completedTask: {
    backgroundColor: "#d3ffd3",
  },
  completedText: {
    textDecorationLine: "line-through",
    color: "#888",
  },
  filterContainer: {
    marginBottom: 20,
  },
  picker: {
    height: 50,
    marginBottom: 10,
  },
  filterTitle: {
    fontSize: 18,
    marginBottom: 10,
  },
  addButton: {
    marginTop: 20,
    padding: 10,
    backgroundColor: "#4CAF50",
    alignItems: "center",
    borderRadius: 5,
  },
  addButtonText: {
    color: "white",
    fontSize: 18,
  },
  modal: {
    position: "absolute",
    top: "30%",
    left: "10%",
    right: "10%",
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    elevation: 5,
  },
  input: {
    height: 40,
    borderColor: "#ddd",
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingLeft: 10,
  },
});

export default TaskListScreen;
