import React, { useState } from "react";
import { View, Text, TextInput, Button, StyleSheet } from "react-native";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";

interface Task {
  id: string;
  title: string;
  date: string;
}

type RootStackParamList = {
  TaskList: undefined;
  EditTask: { task: Task };
};

type EditTaskRouteProp = RouteProp<RootStackParamList, "EditTask">;

const EditTaskScreen = () => {
  const navigation = useNavigation();
  const route = useRoute<EditTaskRouteProp>();
  const [taskTitle, setTaskTitle] = useState(route.params.task.title);
  const [taskDate, setTaskDate] = useState(route.params.task.date);

  const handleSave = () => {
    const updatedTask = { ...route.params.task, title: taskTitle, date: taskDate };
    navigation.navigate("TaskList", { updatedTask });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Görev Başlığını Düzenle:</Text>
      <TextInput style={styles.input} value={taskTitle} onChangeText={setTaskTitle} />

      <Text style={styles.label}>Görev Tarihini Düzenle:</Text>
      <TextInput style={styles.input} value={taskDate} onChangeText={setTaskDate} />

      <Button title="Kaydet" onPress={handleSave} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center", backgroundColor: "#fff" },
  label: { fontSize: 18, marginBottom: 8 },
  input: { borderWidth: 1, padding: 10, borderRadius: 8, marginBottom: 10 },
});

export default EditTaskScreen;
