// App.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';


// Screens
import WelcomeScreen from './src/screens/WelcomeScreen';
import AuthScreen from './src/screens/AuthScreen';
import HomeScreen from './src/screens/HomeScreen';
import NotesScreen from './src/screens/NotesScreen';
import StatsScreen from './src/screens/StatsScreen';
import NoteDetailScreen from './src/screens/NoteDetailScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import DrawingScreen from './src/screens/DrawingScreen';

// Types
import { RootStackParamList, MainTabParamList } from './src/types/navigation';

// Icons
import {
  HomeIcon,
  NotesIcon,
  SettingsIcon,
  StarIcon,
} from './src/components/icons';

// Contexts
import { ThemeProvider } from './src/contexts/ThemeContext';
import { AuthProvider } from './src/contexts/AuthContext';
import { CategoriesProvider } from './src/contexts/CategoriesContext';
import { NotesProvider } from './src/contexts/NotesContext';


const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

const TabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          if (route.name === 'Home') {
            return <HomeIcon size={size} color={color} />;
          }
          if (route.name === 'Notes') {
            return <NotesIcon size={size} color={color} />;
          }
          if (route.name === 'Stats') {
            return <StarIcon size={size} color={color} />;
          }
          if (route.name === 'Settings') {
            return <SettingsIcon size={size} color={color} />;
          }
          return null;
        },
        tabBarActiveTintColor: '#4C6EF5',
        tabBarInactiveTintColor: '#666666',
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopWidth: 1,
          borderTopColor: '#E5E5E5',
          paddingBottom: 8,
          paddingTop: 8,
          height: 60,
        },
        tabBarLabelStyle: {
          fontSize: 12,
          marginTop: 4,
        },
      })}
    >
      <Tab.Screen 
        name="Home" 
        component={HomeScreen}
        options={{
          title: 'Home Page',
          headerShown: false,
        }}
      />
      <Tab.Screen 
        name="Notes" 
        component={NotesScreen}
        options={{
          title: 'My Notes',
          headerShown: false,
        }}
      />
      <Tab.Screen 
        name="Stats" 
        component={StatsScreen}
        options={{
          title: 'Stats',
          headerShown: false,
        }}
      />
      <Tab.Screen 
        name="Settings" 
        component={SettingsScreen}
        options={{
          title: 'Settings',
          headerShown: false,
        }}
      />
    </Tab.Navigator>
  );
};

const App = () => {
  return (
      <ThemeProvider>
        <AuthProvider>
          <CategoriesProvider>
            <NotesProvider>
              <NavigationContainer>
                <Stack.Navigator
                  screenOptions={{
                    headerShown: false,
                  }}
                >
                  <Stack.Screen 
                    name="Welcome" 
                    component={WelcomeScreen}
                  />
                  <Stack.Screen 
                    name="Auth" 
                    component={AuthScreen}
                  />
                  <Stack.Screen 
                    name="MainApp" 
                    component={TabNavigator}
                  />
                  <Stack.Screen 
                    name="NoteDetail" 
                    component={NoteDetailScreen}
                    options={{ 
                      headerShown: true,
                      presentation: 'modal',
                      title: 'Not Detayı',
                      headerStyle: {
                        backgroundColor: '#FFFFFF',
                      },
                      headerShadowVisible: false,
                    }}
                  />
                  <Stack.Screen 
                    name="Drawing" 
                    component={DrawingScreen}
                    options={{ 
                      presentation: 'modal',
                      headerShown: false,
                    }}
                  />
                </Stack.Navigator>
              </NavigationContainer>
            </NotesProvider>
          </CategoriesProvider>
        </AuthProvider>
      </ThemeProvider>
  );
};

export default App;