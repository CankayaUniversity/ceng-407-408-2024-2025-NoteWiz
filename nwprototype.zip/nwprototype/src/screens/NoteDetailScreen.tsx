// src/screens/NoteDetailScreen.tsx
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../types/navigation';
import { useNotes } from '../contexts/NotesContext';
import { useCategories } from '../contexts/CategoriesContext';
import { StarIcon, NotesIcon } from '../components/icons';
import { COLORS, SHADOWS, TYPOGRAPHY, SPACING } from '../constants/theme';
import LinearGradient from 'react-native-linear-gradient';

type NoteDetailScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'NoteDetail'>;
type NoteDetailScreenRouteProp = RouteProp<RootStackParamList, 'NoteDetail'>;

const { width } = Dimensions.get('window');
const FLOATING_BUTTON_SIZE = 56;

const NoteDetailScreen = () => {
  const navigation = useNavigation<NoteDetailScreenNavigationProp>();
  const route = useRoute<NoteDetailScreenRouteProp>();
  const { addNote, updateNote, deleteNote } = useNotes();
  const { categories } = useCategories();
  
  const [isLoading, setIsLoading] = useState(false);
  const [titleHeight, setTitleHeight] = useState(60);

  const noteId = route.params?.noteId;
  const [title, setTitle] = useState(route.params?.title || '');
  const [content, setContent] = useState(route.params?.content || '');
  const [category, setCategory] = useState(route.params?.category || 'Work');
  const [isImportant, setIsImportant] = useState(route.params?.isImportant || false);

  useEffect(() => {
    navigation.setOptions({
      headerTransparent: true,
      headerBlurEffect: 'regular',
      headerStyle: {
        backgroundColor: 'rgba(255, 255, 255, 0.9)',
      },
      headerRight: () => (
        <View style={styles.headerButtons}>
          <TouchableOpacity 
            style={[styles.headerButton, styles.starButton]}
            onPress={() => setIsImportant(!isImportant)}
          >
            <StarIcon 
              size={24} 
              color={isImportant ? COLORS.warning.main : COLORS.neutral[400]} 
            />
          </TouchableOpacity>

          {noteId && (
            <TouchableOpacity
              style={[styles.headerButton, styles.deleteButton]}
              onPress={handleDelete}
            >
              <LinearGradient
                colors={['#FF6B6B', '#FF5252']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.gradientButton}
              >
                <Text style={styles.deleteButtonText}>Delete</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
          
          <TouchableOpacity
            style={[styles.headerButton, styles.saveButton]}
            onPress={handleSave}
          >
            <LinearGradient
              colors={[COLORS.primary[400], COLORS.primary[600]]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.gradientButton}
            >
              <Text style={styles.saveButtonText}>Save</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ),
    });
  }, [navigation, title, content, category, isImportant]);

  const handleSave = async () => {
    if (!title.trim()) {
      Alert.alert('Warning', 'Please enter a title');
      return;
    }

    setIsLoading(true);
    try {
      const noteData = {
        title: title.trim(),
        content: content.trim(),
        category,
        isImportant,
      };

      if (noteId) {
        await updateNote(noteId, noteData);
      } else {
        await addNote(noteData);
      }
      navigation.goBack();
    } catch (error) {
      Alert.alert('Error', 'Failed to save note');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = () => {
    Alert.alert(
      'Delete Note',
      'Are you sure you want to delete this note?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            setIsLoading(true);
            try {
              if (noteId) {
                await deleteNote(noteId);
                navigation.goBack();
              }
            } catch (error) {
              Alert.alert('Error', 'Failed to delete note');
            } finally {
              setIsLoading(false);
            }
          },
        },
      ]
    );
  };

  const selectedCategory = categories.find(cat => cat.id === category);
  const categoryColor = selectedCategory?.color || COLORS.categories.other;

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary.main} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        keyboardDismissMode="interactive"
      >
        <View style={styles.contentContainer}>
          {/* Başlık Alanı */}
          <View style={styles.titleContainer}>
            <TextInput
              style={styles.titleInput}
              placeholder="Title"
              value={title}
              onChangeText={setTitle}
              placeholderTextColor={COLORS.text.tertiary}
              multiline
              onContentSizeChange={(event) => {
                setTitleHeight(event.nativeEvent.contentSize.height);
              }}
            />
          </View>

          {/* Meta Bilgiler */}
          <View style={styles.metaContainer}>
            <TouchableOpacity
              style={[styles.categoryBadge, { backgroundColor: `${categoryColor}20` }]}
            >
              <View style={[styles.categoryDot, { backgroundColor: categoryColor }]} />
              <Text style={[styles.categoryText, { color: categoryColor }]}>
                {selectedCategory?.name || 'Category'}
              </Text>
            </TouchableOpacity>

            <Text style={styles.dateText}>
              {new Date().toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </Text>
          </View>

          {/* İçerik Alanı */}
          <View style={styles.editorContainer}>
            <TextInput
              style={styles.contentInput}
              placeholder="Start writing..."
              value={content}
              onChangeText={setContent}
              multiline
              textAlignVertical="top"
              placeholderTextColor={COLORS.text.tertiary}
            />
          </View>
        </View>
      </ScrollView>

      {/* Drawing FAB */}
      <TouchableOpacity 
        style={styles.fab}
        onPress={() => navigation.navigate('Drawing', { noteId })}
      >
        <LinearGradient
          colors={[COLORS.primary[400], COLORS.primary[600]]}
          style={styles.fabGradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <NotesIcon size={24} color="#FFFFFF" />
        </LinearGradient>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background.default,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  contentContainer: {
    padding: SPACING.lg,
    paddingTop: Platform.OS === 'ios' ? 100 : 80,
  },
  titleContainer: {
    marginBottom: SPACING.md,
  },
  titleInput: {
    fontSize: TYPOGRAPHY.sizes.xxl,
    fontWeight: TYPOGRAPHY.weights.bold,
    color: COLORS.text.primary,
    minHeight: 60,
    padding: 0,
  },
  metaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: SPACING.xl,
  },
  categoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: 20,
  },
  categoryDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: SPACING.xs,
  },
  categoryText: {
    fontSize: TYPOGRAPHY.sizes.sm,
    fontWeight: TYPOGRAPHY.weights.medium,
  },
  dateText: {
    fontSize: TYPOGRAPHY.sizes.sm,
    color: COLORS.text.secondary,
  },
  editorContainer: {
    flex: 1,
    minHeight: 400,
  },
  contentInput: {
    flex: 1,
    fontSize: TYPOGRAPHY.sizes.md,
    color: COLORS.text.primary,
    lineHeight: 24,
    padding: 0,
  },
  headerButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  headerButton: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  gradientButton: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
  },
  starButton: {
    padding: SPACING.sm,
  },
  deleteButton: {
    marginRight: SPACING.xs,
  },
  saveButton: {},
  saveButtonText: {
    color: COLORS.text.inverted,
    fontWeight: TYPOGRAPHY.weights.medium,
    fontSize: TYPOGRAPHY.sizes.sm,
  },
  deleteButtonText: {
    color: COLORS.text.inverted,
    fontWeight: TYPOGRAPHY.weights.medium,
    fontSize: TYPOGRAPHY.sizes.sm,
  },
  fab: {
    position: 'absolute',
    right: SPACING.lg,
    bottom: SPACING.lg,
    width: FLOATING_BUTTON_SIZE,
    height: FLOATING_BUTTON_SIZE,
    borderRadius: FLOATING_BUTTON_SIZE / 2,
    backgroundColor: COLORS.primary.main,
    ...SHADOWS.lg,
    overflow: 'hidden',
  },
  fabGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default NoteDetailScreen;