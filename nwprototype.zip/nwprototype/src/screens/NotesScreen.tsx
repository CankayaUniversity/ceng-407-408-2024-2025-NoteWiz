// src/screens/NotesScreen.tsx
import React, { useState, useCallback } from 'react';
import {
  View,
  StyleSheet,
  SafeAreaView,
  RefreshControl,
  Platform,
  StatusBar,
  Animated,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../types/navigation';
import { useNotes } from '../contexts/NotesContext';
import { useCategories } from '../contexts/CategoriesContext';
import { FloatingActionButton } from '../components/ui/FloatingActionButton';
import { CategoryFilter } from '../components/ui/CategoryFilter';
import { NoteCard } from '../components/notes/NoteCard';
import { EmptyState } from '../components/notes/EmptyState';
import { NotesHeader } from '../components/notes/NotesHeader';
import { COLORS, SHADOWS, SPACING } from '../constants/theme';

const STATUSBAR_HEIGHT = StatusBar.currentHeight || 0;
const HEADER_MAX_HEIGHT = Platform.OS === 'ios' ? 180 : 200;
const HEADER_MIN_HEIGHT = Platform.OS === 'ios' ? 130 : 150;
const HEADER_SCROLL_DISTANCE = HEADER_MAX_HEIGHT - HEADER_MIN_HEIGHT;

const NotesScreen = () => {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { notes, isLoading } = useNotes();
  const { categories } = useCategories();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [refreshing, setRefreshing] = useState(false);
  const scrollY = new Animated.Value(0);

  // Filtreleme
  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         note.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || note.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Header Animasyonu
  const headerHeight = scrollY.interpolate({
    inputRange: [0, HEADER_SCROLL_DISTANCE],
    outputRange: [HEADER_MAX_HEIGHT, HEADER_MIN_HEIGHT],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, HEADER_SCROLL_DISTANCE / 2],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });

  // Yenileme işlemi
  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1500);
  }, []);

  // Not kartına tıklama
  const handleNotePress = (note: any) => {
    navigation.navigate('NoteDetail', {
      noteId: note.id,
      title: note.title,
      content: note.content,
      category: note.category,
      isImportant: note.isImportant
    });
  };

  // Not listesi renderı
  const renderNote = ({ item }: { item: any }) => (
    <NoteCard
      note={item}
      category={categories.find(cat => cat.id === item.category)}
      onPress={() => handleNotePress(item)}
    />
  );

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary.main} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        translucent
        backgroundColor="transparent"
        barStyle="light-content"
      />

      <Animated.View style={[styles.header, { height: headerHeight }]}>
        <Animated.View style={[styles.headerContent, { opacity: headerOpacity }]}>
          <NotesHeader
            totalNotes={notes.length}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />
        </Animated.View>
      </Animated.View>

      <View style={styles.contentContainer}>
        <CategoryFilter
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />

        <FlatList
          data={filteredNotes}
          renderItem={renderNote}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: scrollY } } }],
            { useNativeDriver: false }
          )}
          scrollEventThrottle={16}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              progressViewOffset={HEADER_MAX_HEIGHT}
              colors={[COLORS.primary.main]}
              tintColor={COLORS.primary.main}
            />
          }
          ListEmptyComponent={
            <EmptyState
              query={searchQuery}
              selectedCategory={selectedCategory}
            />
          }
        />
      </View>

      <FloatingActionButton
        onPress={() => navigation.navigate('NoteDetail', {})}
        style={styles.fab}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background.default,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: COLORS.primary.main,
    paddingTop: Platform.OS === 'ios' ? 44 : STATUSBAR_HEIGHT,
    zIndex: 1000,
  },
  headerContent: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: SPACING.md,
  },
  contentContainer: {
    flex: 1,
    marginTop: Platform.OS === 'ios' ? 44 : STATUSBAR_HEIGHT,
  },
  listContent: {
    paddingTop: HEADER_MAX_HEIGHT - (Platform.OS === 'ios' ? 44 : STATUSBAR_HEIGHT),
    paddingHorizontal: SPACING.lg,
    paddingBottom: 100,
  },
  fab: {
    position: 'absolute',
    bottom: SPACING.xl,
    right: SPACING.xl,
    ...SHADOWS.lg,
  },
});

export default NotesScreen;