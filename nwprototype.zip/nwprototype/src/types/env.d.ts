// env.d.ts
declare module '@env' {
    export const OPENAI_API_KEY: string;
    // İleride başka environment variable varsa onları da buraya ekleyebilirsiniz
  }
  